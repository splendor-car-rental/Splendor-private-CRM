import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  query, 
  orderBy,
  writeBatch
} from 'firebase/firestore';
import { db } from './config';
import { handleFirestoreError, OperationType } from './errorHandling';
import { 
  Customer, Lead, Opportunity, Vehicle, Quotation, 
  Reservation, Contract, AdditionalCharge, Deposit, 
  Payment, Invoice, BankImportBatch, BankTransaction, CompanyBankAccount,
  CRMTask, Communication, CRMDocument, AuditLog, 
  CustomFieldDefinition, NumberingConfig, NotificationItem,
  TollTransaction, TollImportBatch
} from '../types';

export const COLLECTIONS = {
  VEHICLES: 'vehicles', CUSTOMERS: 'customers', LEADS: 'leads', OPPORTUNITIES: 'opportunities',
  QUOTATIONS: 'quotations', RESERVATIONS: 'reservations', CONTRACTS: 'contracts', CHARGES: 'charges',
  DEPOSITS: 'deposits', PAYMENTS: 'payments', INVOICES: 'invoices', BANK_BATCHES: 'bank_batches',
  BANK_TRANSACTIONS: 'bank_transactions', COMPANY_BANK_ACCOUNTS: 'company_bank_accounts', TASKS: 'tasks',
  COMMUNICATIONS: 'communications', DOCUMENTS: 'documents', AUDIT_LOGS: 'audit_logs', CUSTOM_FIELDS: 'custom_fields',
  NUMBERING_CONFIGS: 'numbering_configs', NOTIFICATIONS: 'notifications', TOLL_TRANSACTIONS: 'toll_transactions',
  TOLL_IMPORT_BATCHES: 'toll_import_batches', NOTIFICATION_EVENT_CONFIGS: 'notification_event_configs',
  CUSTOM_REMINDERS: 'custom_reminders', WHATSAPP_MESSAGE_LOG: 'whatsapp_message_log',
  CUSTOMER_NOTIFICATION_CONFIGS: 'customer_notification_configs'
} as const;

export class FirestoreService {
  static subscribe<T>(collectionName: string, onData: (items: T[]) => void, onError?: (error: Error) => void): () => void {
    const colRef = collection(db, collectionName);
    const unsubscribe = onSnapshot(query(colRef), snapshot => {
      onData(snapshot.docs.map(docSnap => ({ ...docSnap.data(), id: docSnap.id })) as T[]);
    }, error => {
      console.warn(`Firestore snapshot error for ${collectionName}:`, error);
      if (onError) onError(error); else { try { handleFirestoreError(error, OperationType.LIST, collectionName); } catch {} }
    });
    return unsubscribe;
  }

  static async getAll<T>(collectionName: string): Promise<T[]> {
    try { const snap = await getDocs(collection(db, collectionName)); return snap.docs.map(d => ({ ...d.data(), id: d.id })) as T[]; }
    catch (error) { console.warn(`Failed to fetch ${collectionName} from Firestore:`, error); handleFirestoreError(error, OperationType.LIST, collectionName); return []; }
  }
  static async set(collectionName: string, id: string, data: any): Promise<void> {
    try { await setDoc(doc(db, collectionName, id), { ...data, updatedAt: new Date().toISOString() }, { merge: true }); }
    catch (error) { handleFirestoreError(error, OperationType.WRITE, `${collectionName}/${id}`); }
  }
  static async update(collectionName: string, id: string, data: any): Promise<void> {
    try { await updateDoc(doc(db, collectionName, id), { ...data, updatedAt: new Date().toISOString() }); }
    catch (error) { handleFirestoreError(error, OperationType.UPDATE, `${collectionName}/${id}`); }
  }
  static async remove(collectionName: string, id: string): Promise<void> {
    try { await deleteDoc(doc(db, collectionName, id)); }
    catch (error) { handleFirestoreError(error, OperationType.DELETE, `${collectionName}/${id}`); }
  }

  static async getLiveCollectionStats(): Promise<{ totalDocs: number; counts: Record<string, number>; hasAnyData: boolean }> {
    const collectionsToCheck = [COLLECTIONS.VEHICLES, COLLECTIONS.CUSTOMERS, COLLECTIONS.CONTRACTS, COLLECTIONS.LEADS, COLLECTIONS.RESERVATIONS, COLLECTIONS.QUOTATIONS, COLLECTIONS.INVOICES, COLLECTIONS.BANK_TRANSACTIONS];
    const counts: Record<string, number> = {}; let total = 0;
    await Promise.all(collectionsToCheck.map(async colName => { try { const snap = await getDocs(collection(db, colName)); counts[colName] = snap.size; total += snap.size; } catch { counts[colName] = 0; } }));
    return { totalDocs: total, counts, hasAnyData: total > 0 };
  }

  static async seedFullCRMToFirestore(seedData: {
    vehicles: Vehicle[]; customers: Customer[]; leads: Lead[]; opportunities: Opportunity[]; quotations: Quotation[];
    reservations: Reservation[]; contracts: Contract[]; invoices: Invoice[]; deposits: Deposit[]; payments: Payment[];
    charges: AdditionalCharge[]; bankTransactions: BankTransaction[]; bankBatches: BankImportBatch[];
    companyBankAccounts?: CompanyBankAccount[]; tasks: CRMTask[]; communications: Communication[]; documents: CRMDocument[];
    auditLogs: AuditLog[]; customFields: CustomFieldDefinition[]; numberingConfigs: NumberingConfig[]; notifications: NotificationItem[];
    tollTransactions?: TollTransaction[]; tollImportBatches?: TollImportBatch[];
  }): Promise<{ writtenCount: number }> {
    let written = 0;
    const commitBatchList = async (colName: string, items: any[]) => {
      if (!items?.length) return;
      for (let i = 0; i < items.length; i += 400) {
        const batch = writeBatch(db);
        items.slice(i, i + 400).forEach(item => { const id = item.id || `doc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`; batch.set(doc(db, colName, id), item, { merge: true }); written += 1; });
        await batch.commit();
      }
    };
    await commitBatchList(COLLECTIONS.VEHICLES, seedData.vehicles); await commitBatchList(COLLECTIONS.CUSTOMERS, seedData.customers);
    await commitBatchList(COLLECTIONS.LEADS, seedData.leads); await commitBatchList(COLLECTIONS.OPPORTUNITIES, seedData.opportunities);
    await commitBatchList(COLLECTIONS.QUOTATIONS, seedData.quotations); await commitBatchList(COLLECTIONS.RESERVATIONS, seedData.reservations);
    await commitBatchList(COLLECTIONS.CONTRACTS, seedData.contracts); await commitBatchList(COLLECTIONS.INVOICES, seedData.invoices);
    await commitBatchList(COLLECTIONS.DEPOSITS, seedData.deposits); await commitBatchList(COLLECTIONS.PAYMENTS, seedData.payments);
    await commitBatchList(COLLECTIONS.CHARGES, seedData.charges); await commitBatchList(COLLECTIONS.BANK_TRANSACTIONS, seedData.bankTransactions);
    await commitBatchList(COLLECTIONS.BANK_BATCHES, seedData.bankBatches); await commitBatchList(COLLECTIONS.COMPANY_BANK_ACCOUNTS, seedData.companyBankAccounts || []);
    await commitBatchList(COLLECTIONS.TASKS, seedData.tasks); await commitBatchList(COLLECTIONS.COMMUNICATIONS, seedData.communications);
    await commitBatchList(COLLECTIONS.DOCUMENTS, seedData.documents); await commitBatchList(COLLECTIONS.AUDIT_LOGS, seedData.auditLogs);
    await commitBatchList(COLLECTIONS.CUSTOM_FIELDS, seedData.customFields); await commitBatchList(COLLECTIONS.NUMBERING_CONFIGS, seedData.numberingConfigs);
    await commitBatchList(COLLECTIONS.NOTIFICATIONS, seedData.notifications); await commitBatchList(COLLECTIONS.TOLL_TRANSACTIONS, seedData.tollTransactions || []);
    await commitBatchList(COLLECTIONS.TOLL_IMPORT_BATCHES, seedData.tollImportBatches || []);
    return { writtenCount: written };
  }
}
